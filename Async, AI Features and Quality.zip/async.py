import httpx
from fastapi import FastAPI,HTTPException
app=FastAPI()
@app.get("/quote")
async def quote():
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get("https://api.example.com/quote")
            r.raise_for_status()
        return r.json()
    except httpx.HTTPError:
        raise HTTPException(502, "Upstream service unavailable")